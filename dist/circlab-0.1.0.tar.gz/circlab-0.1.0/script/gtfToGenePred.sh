#!/bin/bash
/home/li/public2/xm/circlab/script/gtfToGenePred "$@"
